//1
int bitXor(int, int);
int test_bitXor(int, int);
//2
int tmax();
int test_tmax();
//3
int logicalShift(int x, int n);
int test_logicalShift(int x, int n);
//4
int allOddBits();
int test_allOddBits();
//5
int conditional(int, int, int);
int test_conditional(int, int, int);
//6
int logicalNeg(int);
int test_logicalNeg(int);
//7
int floatFloat2Int(unsigned);
int test_floatFloat2Int(unsigned);

